import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class LibrarySwing extends JFrame {
    // Database connection
    static final String URL = "jdbc:mysql://localhost:3306/librarydb";
    static final String USER = "root"; 
    static final String PASS = "Daksh@47"; 
    Connection conn;

    // GUI components
    JTextField bookTitle, bookAuthor, bookQty;
    JTextField memberName, memberEmail;
    JTextArea outputArea;
    JTextField issueBookId, issueMemberId, returnIssueId;

    public LibrarySwing() {
        try {
            conn = DriverManager.getConnection(URL, USER, PASS);
            System.out.println("✅ Connected to Database!");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database Connection Failed!");
            e.printStackTrace();
            System.exit(0);
        }

        setTitle("Library Management System");
        setSize(700, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Tabs
        JTabbedPane tabs = new JTabbedPane();

        // --- Add Book Tab ---
        JPanel bookPanel = new JPanel(new GridLayout(5, 2, 10, 10));
        bookPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        bookPanel.add(new JLabel("Book Title:"));
        bookTitle = new JTextField();
        bookPanel.add(bookTitle);
        bookPanel.add(new JLabel("Author:"));
        bookAuthor = new JTextField();
        bookPanel.add(bookAuthor);
        bookPanel.add(new JLabel("Quantity:"));
        bookQty = new JTextField();
        bookPanel.add(bookQty);
        JButton addBookBtn = new JButton("Add Book");
        bookPanel.add(addBookBtn);
        addBookBtn.addActionListener(e -> addBook());
        tabs.add("Add Book", bookPanel);

        // --- Add Member Tab ---
        JPanel memberPanel = new JPanel(new GridLayout(4, 2, 10, 10));
        memberPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        memberPanel.add(new JLabel("Member Name:"));
        memberName = new JTextField();
        memberPanel.add(memberName);
        memberPanel.add(new JLabel("Email:"));
        memberEmail = new JTextField();
        memberPanel.add(memberEmail);
        JButton addMemberBtn = new JButton("Register Member");
        memberPanel.add(addMemberBtn);
        addMemberBtn.addActionListener(e -> addMember());
        tabs.add("Add Member", memberPanel);

        // --- Issue Book Tab ---
        JPanel issuePanel = new JPanel(new GridLayout(4, 2, 10, 10));
        issuePanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        issuePanel.add(new JLabel("Book ID:"));
        issueBookId = new JTextField();
        issuePanel.add(issueBookId);
        issuePanel.add(new JLabel("Member ID:"));
        issueMemberId = new JTextField();
        issuePanel.add(issueMemberId);
        JButton issueBtn = new JButton("Issue Book");
        issuePanel.add(issueBtn);
        issueBtn.addActionListener(e -> issueBook());
        tabs.add("Issue Book", issuePanel);

        // --- Return Book Tab ---
        JPanel returnPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        returnPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        returnPanel.add(new JLabel("Issue ID:"));
        returnIssueId = new JTextField();
        returnPanel.add(returnIssueId);
        JButton returnBtn = new JButton("Return Book");
        returnPanel.add(returnBtn);
        returnBtn.addActionListener(e -> returnBook());
        tabs.add("Return Book", returnPanel);

        // --- View Tab ---
        JPanel viewPanel = new JPanel(new BorderLayout());
        outputArea = new JTextArea();
        outputArea.setEditable(false);
        viewPanel.add(new JScrollPane(outputArea), BorderLayout.CENTER);
        JButton viewBooksBtn = new JButton("View Books");
        viewBooksBtn.addActionListener(e -> viewBooks());
        JButton viewMembersBtn = new JButton("View Members");
        viewMembersBtn.addActionListener(e -> viewMembers());
        JPanel viewBtnPanel = new JPanel();
        viewBtnPanel.add(viewBooksBtn);
        viewBtnPanel.add(viewMembersBtn);
        viewPanel.add(viewBtnPanel, BorderLayout.SOUTH);
        tabs.add("View", viewPanel);

        add(tabs, BorderLayout.CENTER);
        setVisible(true);
    }

    // --- Methods ---
    void addBook() {
        try {
            String sql = "INSERT INTO books (title, author, quantity) VALUES (?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, bookTitle.getText());
            ps.setString(2, bookAuthor.getText());
            ps.setInt(3, Integer.parseInt(bookQty.getText()));
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Book added!");
            bookTitle.setText(""); bookAuthor.setText(""); bookQty.setText("");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    void addMember() {
        try {
            String sql = "INSERT INTO members (name, email) VALUES (?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, memberName.getText());
            ps.setString(2, memberEmail.getText());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Member registered!");
            memberName.setText(""); memberEmail.setText("");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    void issueBook() {
        try {
            int bookId = Integer.parseInt(issueBookId.getText());
            int memberId = Integer.parseInt(issueMemberId.getText());

            String checkQty = "SELECT quantity FROM books WHERE book_id = ?";
            PreparedStatement ps1 = conn.prepareStatement(checkQty);
            ps1.setInt(1, bookId);
            ResultSet rs = ps1.executeQuery();

            if (rs.next() && rs.getInt("quantity") > 0) {
                String sql = "INSERT INTO issued_books (book_id, member_id, issue_date) VALUES (?, ?, CURDATE())";
                PreparedStatement ps2 = conn.prepareStatement(sql);
                ps2.setInt(1, bookId);
                ps2.setInt(2, memberId);
                ps2.executeUpdate();

                String updateQty = "UPDATE books SET quantity = quantity - 1 WHERE book_id = ?";
                PreparedStatement ps3 = conn.prepareStatement(updateQty);
                ps3.setInt(1, bookId);
                ps3.executeUpdate();

                JOptionPane.showMessageDialog(this, "Book issued!");
            } else {
                JOptionPane.showMessageDialog(this, "Book not available!");
            }
            issueBookId.setText(""); issueMemberId.setText("");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    void returnBook() {
        try {
            int issueId = Integer.parseInt(returnIssueId.getText());
            String sql = "UPDATE issued_books SET return_date = CURDATE() WHERE issue_id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, issueId);
            int rows = ps.executeUpdate();

            if (rows > 0) {
                String findBook = "SELECT book_id FROM issued_books WHERE issue_id = ?";
                PreparedStatement ps2 = conn.prepareStatement(findBook);
                ps2.setInt(1, issueId);
                ResultSet rs = ps2.executeQuery();
                if (rs.next()) {
                    int bookId = rs.getInt("book_id");
                    String updateQty = "UPDATE books SET quantity = quantity + 1 WHERE book_id = ?";
                    PreparedStatement ps3 = conn.prepareStatement(updateQty);
                    ps3.setInt(1, bookId);
                    ps3.executeUpdate();
                }
                JOptionPane.showMessageDialog(this, "Book returned!");
            } else {
                JOptionPane.showMessageDialog(this, "Invalid Issue ID!");
            }
            returnIssueId.setText("");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    void viewBooks() {
        try {
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM books");
            outputArea.setText("--- Books ---\n");
            while (rs.next()) {
                outputArea.append("ID: " + rs.getInt("book_id") +
                        " | Title: " + rs.getString("title") +
                        " | Author: " + rs.getString("author") +
                        " | Quantity: " + rs.getInt("quantity") + "\n");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    void viewMembers() {
        try {
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM members");
            outputArea.setText("--- Members ---\n");
            while (rs.next()) {
                outputArea.append("ID: " + rs.getInt("member_id") +
                        " | Name: " + rs.getString("name") +
                        " | Email: " + rs.getString("email") + "\n");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

        public static void main(String[] args) {
        SwingUtilities.invokeLater(LibrarySwing::new);
    }
}
